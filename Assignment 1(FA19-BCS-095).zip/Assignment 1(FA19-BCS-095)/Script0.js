const classNames = {
    TODO_ITEM: 'todo-container',
    TODO_CHECKBOX: 'todo-checkbox',
    TODO_TEXT: 'todo-text',
    TODO_DELETE: 'todo-delete',
  }
   
  const list = document.getElementById('todo-list')
  const itemCountSpan = document.getElementById('item-count')
  const uncheckedCountSpan = document.getElementById('unchecked-count')
  var deleteButtons = document.getElementsByClassName("Remove");

  let count = itemCountSpan.innerHTML;
  let uncheckedCount = uncheckedCountSpan.innerHTML;
   
  function newTodo() {
    let todo = prompt("Enter a new item - ");
    let element = document.createElement("li");
    element.class = classNames["TODO_ITEM"];
    element.id = `item-${count}`;
    let text = document.createElement('div');
    text.class = classNames["TODO_TEXT"];
    text.innerHTML = todo;
    element.appendChild(text);
    let checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.class = classNames["TODO_CHECKBOX"];
    checkbox.checked = false;
    checkbox.addEventListener("click", () => {
      if (checkbox.checked==true)
      {
        uncheckedCount++;
        uncheckedCountSpan.innerHTML = uncheckedCount;
        checkbox.checked = false;
      }
      else {
        uncheckedCount--;
        uncheckedCountSpan.innerHTML = uncheckedCount;
        checkbox.checked = true;
      }
    });
    element.appendChild(checkbox);
    let deleteButton = document.createElement('input');
    deleteButton.type = "button";
    deleteButton.class = classNames["TODO_DELETE"];
    deleteButton.innerHTML = 'DELETE';
    deleteButton.addEventListener("click", () => {
      deleteTodo(element.id);
    });
    element.appendChild(deleteButton);
    count++;
    itemCountSpan.innerHTML = count;
    list.appendChild(element);
  }
   
  function removeTodo(id) {
    let item = document.getElementById(id);
    if (item.querySelector(`.${classNames["TODO_CHECKBOX"]}`).checked == true)
    {
      uncheckedCount++;
      uncheckedCountSpan.innerHTML = uncheckedCount;
    }
    else {
      uncheckedCount--;
      uncheckedCountSpan.innerHTML = uncheckedCount;
    }
    item.remove();
    count--;
    itemCountSpan.innerHTML = count;
    
    const removeall =() =>{
        srtItem([]);
    }
    

  }



/*
  var clonedButton = 
    document.getElementById("buttons").cloneNode(true);
     clonedButton.childNodes[1].addEventListener('click', deleteListItem, false); 

  function deleteListItem(){
    alert("Item was deleted");
  // li.classList.add("delete");
}
*/

const removeTodo = (index) => {
    todosArr.splice(index, 1);
    createTodo(todosArr);
  };
  window.addEventListener("load", () => {
    newTodo(todosArr);
  });